"""TTD review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, os, sys, types, zipfile, re, csv
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/table_transformer_detection_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import table_transformer_detection_pipeline.samples as S
import table_transformer_detection_pipeline.metrics as M
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
md = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown']
alltext = '\n'.join(src(i) for i in range(len(cells)))
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'asserts': [(i, l.strip()) for i in code if i not in (5, 7, 9) for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'doubled_braces_in_markdown': [(i, m) for i in md for m in re.findall(r'\{\{[^}]*\}\}', src(i))],
    'cell1_says_hub_only': 'the Hugging Face Hub only' in src(1), 'cell1_fetches_openfoodfacts': 'static.openfoodfacts.org' in src(1)}
# P2 prose numbers vs the recorded Kaggle T4 run
prose = {i: src(i) for i in (16, 20, 24)}
R['P2_prose_vs_record'] = {
    'prose_quotes': {'cell16': re.findall(r'frozen policy [0-9.]+ % \(mAP [0-9.]+ %\)', prose[16]), 'cell20': re.findall(r'build record: [^—]*— [^.]*\.', prose[20]), 'cell24': re.findall(r'unfrozen with them [0-9.]+ % \(mAP [0-9.]+ %\)', prose[24])},
    'recorded_kaggle_T4_blob_250740ff': {'frozen_policy': {'ap50': 0.3179, 'ap75': 0.0681, 'map': 0.1438}, 'selected_policy': {'ap50': 0.3315, 'ap75': 0.0659, 'map': 0.1288}, 'delta_vs_frozen': {'ap50': 0.0136, 'ap75': -0.0022, 'map': -0.0149}},
    'prose_build_record': {'frozen_policy': {'ap50': 0.376, 'ap75': 0.074, 'map': 0.155}, 'selected_policy': {'ap50': 0.398, 'ap75': 0.134, 'map': 0.163}}}

# P3 rebuild the product split from the carried SAMPLE_RECORDS with stand-in images of the read size, recompute the fixed-box prior
recs = []
for rid, barcode, path, w, h, size, digest, boxes, cats in S.SAMPLE_RECORDS:
    scale = min(1.0, S.CORPUS_LONGEST_SIDE / max(w, h)); W, H = (round(w * scale), round(h * scale)) if scale < 1 else (w, h)
    pb = []
    for chunk in boxes.split(';'):
        ymin, xmin, ymax, xmax = (float(v) for v in chunk.split(','))
        b = [xmin * W, ymin * H, xmax * W, ymax * H]
        if b[2] - b[0] >= S.MIN_BOX_SIDE and b[3] - b[1] >= S.MIN_BOX_SIDE: pb.append(b)
    recs.append({'id': rid, 'image': Image.new('L', (W, H)), 'boxes': pb, 'barcode': barcode})
splits = S.build_sample_dataset(recs, seed=42)
prod = {k: {r['barcode'] for r in v} for k, v in splits.items()}
prior = M.prior_baseline(splits['train'], splits['test'], threshold=0.9)
R['P3_split_and_prior'] = {'photographs': len(recs), 'products': len({r['barcode'] for r in recs}), 'boxes_kept': sum(len(r['boxes']) for r in recs),
    'split_photographs': {k: len(v) for k, v in splits.items()}, 'split_boxes': {k: sum(len(r['boxes']) for r in v) for k, v in splits.items()}, 'split_products': {k: len(v) for k, v in prod.items()},
    'products_shared_between_splits': {'train&test': len(prod['train'] & prod['test']), 'train&validation': len(prod['train'] & prod['validation']), 'validation&test': len(prod['validation'] & prod['test'])},
    'prior_test': {k: round(prior[k], 4) for k in ('ap50', 'ap75', 'map', 'mean_best_iou')}, 'prior_recorded': {'ap50': 0.0266, 'ap75': 0.0, 'map': 0.0054, 'mean_best_iou': 0.3155},
    'note': 'Images are stand-ins of the read size (the host static.openfoodfacts.org is unreachable here); the split and the prior depend only on barcodes, sizes and boxes.'}

# P4 BYOD loader through cell 13's sequence
def jpg(seed, size=(320, 240), exif_orientation=None):
    a = (np.random.default_rng(seed).random((size[1], size[0], 3)) * 255).astype(np.uint8); b = io.BytesIO(); im = Image.fromarray(a)
    if exif_orientation:
        ex = Image.Exif(); ex[0x0112] = exif_orientation; im.save(b, 'JPEG', exif=ex.tobytes())
    else: im.save(b, 'JPEG')
    return b.getvalue()
def ds(n, groups=6, extra=None, csv_extra='', drop_group_row=False):
    files = {f'img{i}.jpg': jpg(i) for i in range(n)}
    rows = 'id,file,group,x_min,y_min,x_max,y_max\n' + ''.join(f'p{i},img{i}.jpg,{"" if (drop_group_row and i == 0) else "g" + str(i % groups)},20,30,200,180\n' for i in range(n))
    files['boxes.csv'] = (rows + csv_extra).encode(); files.update(extra or {}); return files
def mkzip(name, files):
    p = out / name
    with zipfile.ZipFile(p, 'w') as z:
        for k, v in files.items(): z.writestr(k, v)
    return p
def nb_byod(p):
    recs = S.load_byod_dataset(p); sp = S.split_dataset(recs, seed=42)
    m = {k: S.validate_dataset(v) for k, v in sp.items()}; d = S.check_split_disjoint(sp)
    return {k: x['n_records'] for k, x in m.items()}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:220]}
smallest = None
for n in range(8, 120):
    if run('n', lambda n=n: nb_byod(mkzip('scan.zip', ds(n, groups=n))))['verdict'] == 'accepted': smallest = n; break
cases = [
    run('60 photos, 12 groups', lambda: nb_byod(mkzip('g12.zip', ds(60, 12)))),
    run('60 photos, 3 groups', lambda: nb_byod(mkzip('g3.zip', ds(60, 3)))),
    run('one row without group', lambda: nb_byod(mkzip('nog.zip', ds(60, 12, drop_group_row=True)))),
    run('boxes.csv names a missing image', lambda: nb_byod(mkzip('miss.zip', ds(60, 12, csv_extra='p99,nothere.jpg,g1,1,1,50,50\n')))),
    run('box outside the image', lambda: nb_byod(mkzip('out.zip', ds(60, 12, csv_extra='p0,img0.jpg,g0,10,10,900,900\n')))),
    run('two members named img0.jpg', lambda: nb_byod(mkzip('dup.zip', {**ds(60, 12), 'b/img0.jpg': jpg(999)}))),
    run('macOS zip (__MACOSX/._img0.jpg)', lambda: nb_byod(mkzip('mac.zip', {**ds(60, 12), '__MACOSX/._img0.jpg': b'\0\5\26\7'}))),
    run('EXIF orientation 6 photo, boxes in displayed frame', lambda: nb_byod(mkzip('exif.zip', {**ds(60, 12), 'img0.jpg': jpg(0, exif_orientation=6)}))),
]
R['P4_byod'] = {'stated_minimum': 'a training set needs 8..2,000 records', 'smallest_accepted_one_group_per_photo': smallest, 'matrix': cases,
    'exif_note': 'load_byod_dataset calls image.convert(RGB) without ImageOps.exif_transpose; the corpus itself skips two EXIF-tagged originals (SKIPPED_EXIF)'}
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True'); head = c13.split('    records = load_byod_dataset')[0]
def exec_upload(up, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: up)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(out)
    try:
        ns = {'Path': Path, 'os': os, 'time': __import__('time')}; exec(compile(head, 'cell13', 'exec'), ns); return ns.get('file_name')
    finally: os.chdir(cwd)
R['P5_upload'] = {'cancelled': run('cancelled', lambda: exec_upload({})), 'outside Colab': run('outside', lambda: exec_upload(None, colab=False)), 'has_path_field': bool(re.search(r'BYOD_(PATH|ZIP)\s*=', src(13)))}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
for p in out.glob('*.zip'): p.unlink()
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:9000])
